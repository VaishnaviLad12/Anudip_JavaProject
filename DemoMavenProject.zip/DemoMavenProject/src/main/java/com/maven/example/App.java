package com.maven.example;


/**
 * MavenExample class
 * This class contains the main method which prints "Welcome to Maven".
 */
public class App 

    {
    public static void main(String[] args) {
        System.out.println("Welcome to Maven");
    }
    
}



