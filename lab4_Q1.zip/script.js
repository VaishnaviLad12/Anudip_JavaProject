document.getElementById('taxForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    var income = parseFloat(document.getElementById('income').value);
    var tax = calculateTax(income);
    
    var resultElement = document.getElementById('result');
    resultElement.textContent = 'Your income tax is: $' + tax.toFixed(2);
});

function calculateTax(income) {
    var tax = 0;
    
    if (income <= 48535) {
        tax = income * 0.15;
    } else if (income <= 97069) {
        tax = 48535 * 0.15 + (income - 48535) * 0.205;
    } else if (income <= 150473) {
        tax = 48535 * 0.15 + (97069 - 48535) * 0.205 + (income - 97069) * 0.26;
    } else if (income <= 214368) {
        tax = 48535 * 0.15 + (97069 - 48535) * 0.205 + (150473 - 97069) * 0.26 + (income - 150473) * 0.29;
    } else {
        tax = 48535 * 0.15 + (97069 - 48535) * 0.205 + (150473 - 97069) * 0.26 + (214368 - 150473) * 0.29 + (income - 214368) * 0.33;
    }
    
    return tax;
}
