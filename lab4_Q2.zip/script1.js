document.getElementById('calculate').addEventListener('click', function() {
    var moviePrice = parseFloat(document.getElementById('movie').value);
    var tickets = parseInt(document.getElementById('tickets').value);
    var totalCost = moviePrice * tickets;

    var totalCostElement = document.getElementById('totalCost');
    totalCostElement.textContent = 'Total Cost: $' + totalCost.toFixed(2);
});
