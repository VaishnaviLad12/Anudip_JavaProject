package org.anudip.test;

public class JarExample {
    public static void main(String[] args) {
        System.out.println("Successfully executed Jar");
    }
}
