/*
Write JUnit test methods for a ListUtils class that provides utility methods for manipulating lists. Test methods to find the maximum element, 
reverse a list, and check for an element's presence. Use assertion methods to validate outcomes. 
*/



package anudip.com;

import java.util.Collections;
import java.util.List;



/**
 * Utility class for common operations on lists.
 */

public class ListUtils {
	
	 /**
     * Finds the maximum element in the list.
     * 
     * @param list The list to search for the maximum element
     * @param <T> The type of elements in the list, must implement Comparable interface
     * @return The maximum element in the list
     * @throws IllegalArgumentException if the list is null or empty
     */
	
	
	public static <T extends Comparable<T>> T findMax(List<T> list) {
        if (list == null || list.isEmpty()) {
            throw new IllegalArgumentException("List must not be null or empty");
        }
        return Collections.max(list);
    }
	
	/**
     * Reverses the elements in the list.
     * 
     * @param list The list to be reversed
     * @param <T> The type of elements in the list
     * @return The reversed list
     * @throws IllegalArgumentException if the list is null
     */

    public static <T> List<T> reverse(List<T> list) {
        if (list == null) {
            throw new IllegalArgumentException("List must not be null");
        }
        Collections.reverse(list);
        return list;
    }
    

    /**
     * Checks if the list contains a specific element.
     * 
     * @param list The list to be checked
     * @param element The element to search for in the list
     * @param <T> The type of elements in the list
     * @return true if the element is found in the list, false otherwise
     * @throws IllegalArgumentException if the list is null
     */

    public static <T> boolean contains(List<T> list, T element) {
        if (list == null) {
            throw new IllegalArgumentException("List must not be null");
        }
        return list.contains(element);
    }
}










    