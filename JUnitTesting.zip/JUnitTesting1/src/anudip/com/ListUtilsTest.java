package anudip.com;

import static org.junit.Assert.*;
import org.junit.Test;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Test class for ListUtils to validate its methods.
 */

public class ListUtilsTest {
	
	
	 /**
     * Tests the findMax method with a list of integers and strings.
     */

    @Test
    public void testFindMax() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        assertEquals(Integer.valueOf(5), ListUtils.findMax(list));

        List<String> stringList = Arrays.asList("apple", "banana", "cherry");
        assertEquals("cherry", ListUtils.findMax(stringList));
    }
    
    /**
     * Tests the findMax method with null input, expecting an IllegalArgumentException.
     */

    @Test(expected = IllegalArgumentException.class)
    public void testFindMaxWithNull() {
        ListUtils.findMax(null);
    }
    
    /**
     * Tests the findMax method with an empty list, expecting an IllegalArgumentException.
     */

    @Test(expected = IllegalArgumentException.class)
    public void testFindMaxWithEmptyList() {
        ListUtils.findMax(Collections.emptyList());
    }
    
    /**
     * Tests the reverse method by comparing a list with its reversed version.
     */

    @Test
    public void testReverse() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        List<Integer> reversedList = Arrays.asList(5, 4, 3, 2, 1);
        assertEquals(reversedList, ListUtils.reverse(list));
    }

    

    /**
     * Tests the reverse method with null input, expecting an IllegalArgumentException.
     */
    
    @Test(expected = IllegalArgumentException.class)
    public void testReverseWithNull() {
        ListUtils.reverse(null);
    }


    /**
     * Tests the contains method to check if an element exists in the list.
     */
    
    @Test
    public void testContains() {
        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);
        assertTrue(ListUtils.contains(list, 3));
        assertFalse(ListUtils.contains(list, 6));
    }
    
    /**
     * Tests the contains method with null input, expecting an IllegalArgumentException.
     */

    @Test(expected = IllegalArgumentException.class)
    public void testContainsWithNull() {
        ListUtils.contains(null, 1);
    }
}















































