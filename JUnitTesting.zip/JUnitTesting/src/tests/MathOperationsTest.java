/*
 Create test methods for a MathOperations class that provides basic arithmetic operations. Write tests to cover addition, subtraction, 
 multiplication, and division. Use parameterized tests to test different input values. 
 */

package tests;

import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import java.util.Arrays;
import java.util.Collection;

//Main test class for MathOperations
@RunWith(Parameterized.class)
public class MathOperationsTest {

    private int a;
    private int b;
    private int expected;
    private String operation;


 // Constructor for parameterized tests
    public MathOperationsTest(String operation, int a, int b, int expected) {
    	
    	
    	this.operation = operation;
        this.a = a;
        this.b = b;
        this.expected = expected;
    }
    
    
    // Define the parameters for the tests
    
    @Parameterized.Parameters(name = "{index}: test{0}({1},{2}) = {3}")
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{
        	
        	 // Addition tests
        	
            {"Add", 1, 1, 2},
            {"Add", 2, 3, 5},
            {"Add", -1, 1, 0},
            {"Add", -1, -1, -2},
            
            // Subtraction tests
            
            {"Subtract", 5, 3, 2},
            {"Subtract", 2, 2, 0},
            {"Subtract", 1, -1, 2},
            {"Subtract", -1, -1, 0},
            
         // Multiplication tests
            
            {"Multiply", 2, 3, 6},
            {"Multiply", 5, 5, 25},
            {"Multiply", -1, 1, -1},
            {"Multiply", -2, -2, 4},
            
         // Division tests
            
            {"Divide", 6, 3, 2},
            {"Divide", 5, 1, 5},
            {"Divide", 10, 2, 5},
            {"Divide", -6, -3, 2}
        });
    }

    // Test method for arithmetic operations
    @Test
    public void testOperations() {
        int result = 0;
        switch (operation) {
            case "Add":
                result = MathOperations.add(a, b);
                break;
            case "Subtract":
                result = MathOperations.subtract(a, b);
                break;
            case "Multiply":
                result = MathOperations.multiply(a, b);
                break;
            case "Divide":
                result = MathOperations.divide(a, b);
                break;
        }
        assertEquals(expected, result);
    }
    
    // Nested test class for testing division by zero

    @RunWith(Parameterized.class)
    public static class DivisionByZeroTest {

        private int a;
        private int b;
        
        
     // Constructor for initializing parameters
        public DivisionByZeroTest(int a, int b) {
            this.a = a;
            this.b = b;
        }
     // Parameterized test data for division by zero
        @Parameterized.Parameters(name = "{index}: testDivideByZero({0},{1})")
        public static Collection<Object[]> data() {
            return Arrays.asList(new Object[][]{
                {1, 0},
                {10, 0},
                {-5, 0}
            });
        }
     // Test method for division by zero
        @Test
        public void testDivideByZero() {
            assertThrows(IllegalArgumentException.class, () -> MathOperations.divide(a, b));
        }
    }
}

	













    
        

    