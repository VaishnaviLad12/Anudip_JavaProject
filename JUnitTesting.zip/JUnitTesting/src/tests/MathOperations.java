/*
 Create test methods for a MathOperations class that provides basic arithmetic operations. Write tests to cover addition, subtraction, 
 multiplication, and division. Use parameterized tests to test different input values. 
 */




package tests;

/**
 * MathOperations class that provides basic arithmetic operations.
 */

public class MathOperations {
	
	/**
     * Adds two integers.
     * @param a the first integer
     * @param b the second integer
     * @return the sum of a and b
     */
	
	
	 public static int add(int a, int b) {
	        return a + b;
	    }

	 
	 /**
	     * Subtracts the second integer from the first integer.
	     * @param a the first integer
	     * @param b the second integer
	     * @return the result of subtracting b from a
	     */
	 
	    public static int subtract(int a, int b) {
	        return a - b;
	    }
	    
	    /**
	     * Performs multiplication of two integers.
	     * 
	     * @param a The first operand
	     * @param b The second operand
	     * @return The result of the multiplication operation
	     */

	    public static int multiply(int a, int b) {
	        return a * b;
	    }

	    
	    /**
	     * Performs division of two integers.
	     * 
	     * @param a The dividend
	     * @param b The divisor
	     * @return The result of the division operation
	     * @throws IllegalArgumentException if the divisor is zero
	     */
	    public static int divide(int a, int b) {
	        if (b == 0) {
	            throw new IllegalArgumentException("Division by zero is not allowed.");
	        }
	        return a / b;
	    }
	}




   